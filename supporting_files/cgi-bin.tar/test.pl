#!/usr/bin/perl -w
print "Content-type: text/html\r\n\r\n";
print "CGI working perfectly!! \n";
