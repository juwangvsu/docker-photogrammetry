#!/usr/bin/perl
use strict;
use warnings;
use base 'CGI::Application'; 
print qq(Content-type: text/plain\n\n);
 
print "hi\n";
