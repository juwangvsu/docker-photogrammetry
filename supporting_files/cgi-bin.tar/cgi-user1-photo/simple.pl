#!/usr/bin/perl
use strict;
use lib '/usr/lib/cgi-bin/cgi-user1-photo/libs';
use MyLib::Simple;

my $webapp = MyLib::Simple->new(
  PARAMS => {
    cfg_file => ['simple.ini'],
    format => 'equal',
  },
);
$webapp->run();

