#!/usr/bin/perl
use strict;
use warnings;
 
print qq(Content-type: text/plain\n\n);
 
print "hi\n";
