#!/bin/bash
printf "Content-type: text/html\n\n"
printf "Hello World!\n"
