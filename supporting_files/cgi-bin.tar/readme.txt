test.pl should work right the way
echo.pl need certain cgi package

http://x.x.x.x/cgi-bin/test.pl
